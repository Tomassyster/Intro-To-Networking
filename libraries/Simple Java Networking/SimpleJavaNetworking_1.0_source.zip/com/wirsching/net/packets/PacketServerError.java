package com.wirsching.net.packets;


public class PacketServerError extends Packet {

	public PacketServerError() {
		id = "server_error";
	}
	
}
